class Clientes {
    clientes;
    constructor() {
        this.clientes = new Array();
        const conta1 = new Conta("1", 100);
        const conta2 = new Conta("2", 200);
        const cli1 = new Cliente("Ricardo", "123.456.789-09", conta1);
        const cli2 = new Cliente("Gustavo", "213.567.983-18", conta2);
        this.clientes.push(cli1, cli2);
    }
    inserir(cliente) {
        this.clientes.push(cliente);
    }
    remover(nome) {
        const clienteARemover = this.pesquisar(nome);
        if (clienteARemover) {
            const indiceCliente = this.clientes.indexOf(clienteARemover);
            if (indiceCliente > -1) {
                this.clientes.splice(indiceCliente, 1);
            }
        }
    }
    pesquisar(nome) {
        return this.clientes.find(cliente => cliente.nome === nome);
    }
    listar() {
        return this.clientes;
    }
}
